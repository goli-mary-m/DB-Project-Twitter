create
    definer = root@localhost procedure send_message(IN in_receiver_username varchar(20), IN in_content_type int,
                                                    IN in_text varchar(256), IN in_post_id int)
BEGIN
    	CALL get_current_user (@current_username);
        
        IF in_content_type = 0 THEN
        	-- message -> text
			INSERT INTO `message`(`sender_username`, `receiver_username`, `content_type`, `content_text`) 
			SELECT sender.username, receiver.username, 'text', in_text
			FROM user_account AS sender, user_account AS receiver
			WHERE sender.username = @current_username AND receiver.username = in_receiver_username
     			  AND (receiver.username, sender.username) 
                       NOT IN (SELECT blocker_username , blocking_username FROM block);
      
		ELSEIF in_content_type = 1 THEN
			-- message -> post
			INSERT INTO `message`(`sender_username`, `receiver_username`, `content_type`, `content_post_id`) 
			SELECT sender.username, receiver.username, 'post', post_id
			FROM user_account AS sender, user_account AS receiver, post
			WHERE sender.username = @current_username AND receiver.username = in_receiver_username 
                  AND post_id = in_post_id
      	      	  AND (receiver.username, sender.username) 
                       NOT IN (SELECT blocker_username , blocking_username FROM block)
              	  AND (post_username, sender.username) 
                       NOT IN (SELECT blocker_username , blocking_username FROM block);
     
		END IF;
        
    END;


create
    definer = root@localhost procedure block_user(IN in_blocking_username varchar(20))
BEGIN 
    	CALL get_current_user (@current_username);
        
        INSERT INTO `block`(`blocker_username`, `blocking_username`) 
		VALUES 
		-- blocker_username
		((SELECT username
      	  FROM user_account
          WHERE username = @current_username),
     
     	-- blocking username
     	(SELECT username
         FROM user_account
         WHERE username = in_blocking_username));
    END;


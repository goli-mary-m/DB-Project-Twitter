create
    definer = root@localhost procedure get_user_posts()
BEGIN
    	CALL get_current_user (@current_username);
        
        SELECT post_id, post_content
		FROM post
		WHERE post_username = @current_username;
    END;


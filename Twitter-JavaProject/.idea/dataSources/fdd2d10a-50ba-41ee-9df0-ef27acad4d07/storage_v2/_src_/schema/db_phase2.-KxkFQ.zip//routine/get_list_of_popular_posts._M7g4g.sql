create
    definer = root@localhost procedure get_list_of_popular_posts()
BEGIN
    	CALL get_current_user (@current_username);
        
        SELECT like_post.post_id, COUNT(like_username) AS number_of_likes
		FROM like_post, post
		WHERE like_post.post_id = post.post_id
      		  AND (post_username, @current_username) 
                   NOT IN  (SELECT blocker_username , blocking_username FROM block)
		GROUP BY like_post.post_id
		ORDER BY number_of_likes DESC;
    END;


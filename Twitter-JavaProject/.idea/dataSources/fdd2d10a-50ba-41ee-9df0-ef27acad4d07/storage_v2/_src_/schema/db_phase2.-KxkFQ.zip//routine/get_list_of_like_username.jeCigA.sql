create
    definer = root@localhost procedure get_list_of_like_username(IN in_post_id int)
BEGIN
    	CALL get_current_user (@current_username);
        
        SELECT like_username
		FROM  like_post , post
		WHERE like_post.post_id = post.post_id 
              AND like_post.post_id = in_post_id
	          AND (post_username, @current_username) 
                   NOT IN  (SELECT blocker_username , blocking_username FROM block)
              AND (like_username, @current_username) 
                   NOT IN  (SELECT blocker_username , blocking_username FROM block);
    END;


create
    definer = root@localhost procedure follow_user(IN in_following_username varchar(20))
BEGIN
    	CALL get_current_user (@current_username);
        
        INSERT INTO `follow`(`follower_username`, `following_username`) 
		VALUES 
		-- follower_username
		((SELECT username 
      	  FROM user_account 
      	  WHERE username = @current_username),
     
     	-- following_username
     	(SELECT username 
         FROM user_account 
         WHERE username = in_following_username));
    END;


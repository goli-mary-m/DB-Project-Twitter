create definer = root@localhost trigger hashtag_trigger
    after insert
    on post
    for each row
BEGIN
        	DECLARE p_content VARCHAR(256);
            DECLARE tmp VARCHAR(256);
            DECLARE p_content_length INT;
            DECLARE h_index INT;
            DECLARE h_index_curr INT;
            DECLARE h_index_next INT;
            DECLARE h_content CHAR(6);
            
            SET p_content = NEW.post_content;        
            SELECT LENGTH (p_content) INTO p_content_length;
             
            SELECT INSTR(p_content, '#') INTO h_index;
            IF h_index > 0 THEN
            	WHILE (p_content_length > 0 AND p_content_length IS NOT NULL) DO
            		SELECT INSTR(p_content, '#') INTO h_index_curr;
                	SELECT SUBSTR(p_content, h_index_curr+1) INTO tmp;
                	SELECT INSTR(tmp, '#') INTO h_index_next;
                	IF h_index_next = 0 THEN
                		SET h_index_next = p_content_length;
                	END IF;
                
                	IF (h_index_next = 6) THEN
                		-- valid hashtag
                		SELECT SUBSTR(p_content, h_index_curr, 6) INTO h_content;
                    	CALL add_hashtag (NEW.post_id, h_content);
					END IF;
                
                	SELECT SUBSTR(p_content, h_index_curr+h_index_next) INTO p_content;
               	 	SELECT LENGTH (p_content) INTO p_content_length;
                
				END WHILE;
			END IF;
            
        END;


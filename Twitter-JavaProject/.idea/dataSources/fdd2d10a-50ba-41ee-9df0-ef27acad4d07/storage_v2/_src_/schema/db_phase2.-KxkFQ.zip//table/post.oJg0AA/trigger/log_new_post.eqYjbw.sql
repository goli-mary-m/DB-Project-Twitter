create definer = root@localhost trigger log_new_post
    after insert
    on post
    for each row
BEGIN
        	INSERT INTO `table_new_post`(`post_id`, `post_username`, `post_time`) 
            VALUES (NEW.post_id, NEW.post_username, NEW.post_time);
        END;


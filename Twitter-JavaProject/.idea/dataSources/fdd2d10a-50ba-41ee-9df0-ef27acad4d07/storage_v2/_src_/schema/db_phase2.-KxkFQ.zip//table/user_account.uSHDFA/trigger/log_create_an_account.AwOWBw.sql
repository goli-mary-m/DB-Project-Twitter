create definer = root@localhost trigger log_create_an_account
    after insert
    on user_account
    for each row
BEGIN
        	INSERT INTO `table_create_an_account`(`username`, `reg_date`) 
            VALUES (NEW.username, NEW.reg_date);
        END;


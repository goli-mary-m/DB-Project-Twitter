create
    definer = root@localhost procedure like_posts(IN in_post_id int)
BEGIN
    	CALL get_current_user (@current_username);
        
        INSERT INTO `like_post`(`like_username`, `post_id`) 
		SELECT username, post_id
		FROM user_account, post
		WHERE username = @current_username AND post_id = in_post_id
     		  AND (post_username, username) 
                   NOT IN (SELECT blocker_username , blocking_username FROM block);
    END;


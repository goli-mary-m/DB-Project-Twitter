create
    definer = root@localhost procedure unfollow_user(IN in_following_username varchar(20))
BEGIN
    	CALL get_current_user (@current_username);
        
        DELETE FROM `follow` 
		WHERE follower_username = @current_username 
              AND following_username = in_following_username;

    END;


create
    definer = root@localhost procedure create_an_account(IN firstname varchar(20), IN lastname varchar(20),
                                                         IN username varchar(20), IN pass varchar(128),
                                                         IN birth_date date, IN biography varchar(64))
BEGIN
    	INSERT INTO `user_account` (`first_name`, `last_name`, `username`, `pass`, `birth_date`, `biography`) 
		VALUES    
      	(firstname, lastname, username, SHA1(pass), birth_date, biography);
	END;


create
    definer = root@localhost procedure unblock_user(IN in_blocking_username varchar(20))
BEGIN
    	CALL get_current_user (@current_username);
        
        DELETE FROM `block` 
		WHERE blocker_username = @current_username 
              AND blocking_username = in_blocking_username;
    END;


create
    definer = root@localhost procedure get_comments(IN in_post_id int)
BEGIN
    	CALL get_current_user (@current_username);
        
        SELECT post_comment.comment1_post_id, comment1_post.post_content AS comment_1_post_content
		FROM post AS main_post, post AS comment1_post, post_comment
		WHERE main_post.post_id = in_post_id AND main_post.post_id = post_comment.post_id 
      		  AND comment1_post.post_id = post_comment.comment1_post_id
              AND post_comment.comment2_post_id IS NULL
              AND (main_post.post_username, @current_username) 
                   NOT IN (SELECT blocker_username , blocking_username FROM block)
              AND (comment1_post.post_username, @current_username) 
                  NOT IN (SELECT blocker_username , blocking_username FROM block);
    END;


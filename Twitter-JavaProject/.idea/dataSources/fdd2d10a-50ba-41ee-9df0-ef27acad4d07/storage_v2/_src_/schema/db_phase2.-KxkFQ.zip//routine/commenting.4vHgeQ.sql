create
    definer = root@localhost procedure commenting(IN in_post_id int, IN comment_type int,
                                                  IN comment1_content varchar(256), IN in_comment1_id int,
                                                  IN comment2_content varchar(256))
BEGIN
    	CALL get_current_user (@current_username);
        
        IF comment_type = 1 THEN
        	-- comment 1
			INSERT INTO `post`(`post_content`, `post_username`) 
			VALUES (comment1_content, @current_username);

			INSERT INTO `post_comment`(`post_id`, `comment1_post_id`) 
			SELECT main_post.post_id, comment1_post.post_id
			FROM post AS main_post, post AS comment1_post
			WHERE main_post.post_id = in_post_id 
                  AND comment1_post.post_id = (SELECT MAX(post_id) FROM post)
      			  AND (main_post.post_username, comment1_post.post_username) 
                      NOT IN (SELECT blocker_username , blocking_username FROM block);
      
			DELETE FROM `post` 
			WHERE post_id = (SELECT MAX(post_id) FROM post) 
      			  AND NOT EXISTS
      					(
         				SELECT main_post.post_id, comment1_post.post_id
		 				FROM post AS main_post, post AS comment1_post
						WHERE main_post.post_id = in_post_id 
                              AND comment1_post.post_id = (SELECT MAX(post_id) FROM post)
               				  AND (main_post.post_username, comment1_post.post_username) 
                                   NOT IN (SELECT blocker_username , blocking_username FROM block)
         				);
         
         
         ELSEIF comment_type = 2 THEN
			-- comment 2
			INSERT INTO `post`(`post_content`, `post_username`) 
			VALUES (comment2_content, @current_username);

			INSERT INTO `post_comment`(`post_id`, `comment1_post_id`, `comment2_post_id`) 
			SELECT main_post.post_id, comment1_post.post_id, comment2_post.post_id
			FROM post AS main_post, post AS comment1_post, post AS comment2_post
			WHERE main_post.post_id = in_post_id AND comment1_post.post_id = in_comment1_id 
                  AND comment2_post.post_id = (SELECT MAX(post_id) FROM post)
      			  AND (comment1_post.post_username, comment2_post.post_username) 
                       NOT IN (SELECT blocker_username , blocking_username FROM block);
      
			DELETE FROM `post` 
			WHERE post_id = (SELECT MAX(post_id) FROM post) 
      			  AND NOT EXISTS
      					(
         				SELECT main_post.post_id, comment1_post.post_id, comment2_post.post_id
		 				FROM post AS main_post, post AS comment1_post, post AS comment2_post
		 				WHERE main_post.post_id = in_post_id AND comment1_post.post_id = in_comment1_id 
                              AND comment2_post.post_id = (SELECT MAX(post_id) FROM post)
               			      AND (comment1_post.post_username, comment2_post.post_username) 
                                   NOT IN (SELECT blocker_username , blocking_username FROM block)
         				);
                        
		END IF;

    END;


create
    definer = root@localhost procedure new_post(IN in_content varchar(256))
BEGIN
    	CALL get_current_user (@current_username);
        
    	INSERT INTO `post`(`post_content`, `post_username`) 
		VALUES
		(in_content, @current_username);			
    END;


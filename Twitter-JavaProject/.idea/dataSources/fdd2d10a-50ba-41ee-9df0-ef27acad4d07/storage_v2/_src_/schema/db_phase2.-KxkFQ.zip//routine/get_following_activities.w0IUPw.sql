create
    definer = root@localhost procedure get_following_activities()
BEGIN
    	CALL get_current_user (@current_username);
        
        SELECT post_content, post_time
		FROM post
		WHERE 
			post_username IN (SELECT following_username
                      		  FROM follow 
                              WHERE follower_username = @current_username)
			AND
    		post_username NOT IN (SELECT blocker_username
                          		  FROM block
                                  WHERE blocking_username = @current_username)
                          
		ORDER BY post_time DESC;

    END;


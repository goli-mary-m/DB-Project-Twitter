create
    definer = root@localhost procedure login(IN in_username varchar(20), IN in_pass varchar(128))
BEGIN
    	INSERT INTO `login_users`(`username`)
			SELECT username
   			FROM user_account
			WHERE username = in_username AND pass = SHA1(in_pass);
    END;


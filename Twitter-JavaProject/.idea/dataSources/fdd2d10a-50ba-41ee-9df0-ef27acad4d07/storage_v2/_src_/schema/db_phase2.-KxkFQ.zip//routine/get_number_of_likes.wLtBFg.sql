create
    definer = root@localhost procedure get_number_of_likes(IN in_post_id int)
BEGIN
    	CALL get_current_user (@current_username);
        
        SELECT COUNT(like_username) AS number_of_likes
		FROM  like_post , post
		WHERE like_post.post_id = post.post_id 
              AND like_post.post_id = in_post_id
	          AND (post_username, @current_username) 
                   NOT IN  (SELECT blocker_username , blocking_username FROM block);
    END;


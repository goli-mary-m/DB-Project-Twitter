create
    definer = root@localhost procedure get_current_user(OUT out_username varchar(20))
BEGIN
    	SELECT username INTO out_username 
        FROM login_users
        ORDER BY login_time DESC
        LIMIT 1;
    END;


create
    definer = root@localhost procedure get_user_activities(IN in_username varchar(20))
BEGIN
    	CALL get_current_user (@current_username);
        
        SELECT post_content
		FROM post
		WHERE post_username = in_username 
              AND post_username 
              	  NOT IN (SELECT blocker_username
                          FROM block
                          WHERE blocking_username = @current_username);

    END;


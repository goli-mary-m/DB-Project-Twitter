create
    definer = root@localhost procedure get_posts_with_specific_hashtag(IN in_hashtag_content char(6))
BEGIN
    	CALL get_current_user (@current_username);
        
        SELECT post.post_id, post.post_content, post.post_username, post.post_time
		FROM post_hashtag, post
		WHERE post_hashtag.post_id = post.post_id 
              AND hashtag_content = in_hashtag_content
              AND (post_username, @current_username) 
                   NOT IN (SELECT blocker_username , blocking_username FROM block)
		ORDER BY post_time DESC;
    END;


create
    definer = root@localhost procedure add_hashtag(IN in_post_id int, IN in_hashtag_content char(6))
BEGIN
    	CALL get_current_user (@current_username);
        
        INSERT INTO `post_hashtag`(`hashtag_content`, `post_id`) 
		VALUES 
		(in_hashtag_content, (SELECT post_id
                              FROM post
                              WHERE post_id = in_post_id 
                                    AND post_username = @current_username));
     
		INSERT INTO `hashtag`(`content`) 
		SELECT hashtag_content 
		FROM post_hashtag 
		WHERE hashtag_content = in_hashtag_content 
              AND hashtag_content NOT IN (SELECT content FROM hashtag)
	          AND EXISTS (SELECT post_id
                          FROM post
                          WHERE post_id = in_post_id 
                                AND post_username = @current_username);
    END;


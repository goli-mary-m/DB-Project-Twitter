create
    definer = root@localhost procedure get_user_logins()
BEGIN
    	CALL get_current_user (@out_username);
        
    	SELECT login_time
		FROM login_users
		WHERE username = @out_username
		ORDER BY login_time  DESC;
    END;


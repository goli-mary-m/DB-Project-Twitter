create
    definer = root@localhost procedure get_list_of_sender_username()
BEGIN
    	CALL get_current_user (@current_username);
        
        SELECT DISTINCT senders.sender_username 
		FROM (SELECT sender_username, send_time
      		  FROM message
              WHERE receiver_username = @current_username AND content_type = 'text'
      
      		  UNION
      
      		  SELECT sender_username, send_time
      	      FROM message, post
      	      WHERE receiver_username = @current_username AND content_type = 'post' 
                    AND message.content_post_id = post.post_id
                    AND (post_username, receiver_username) 
                         NOT IN (SELECT blocker_username , blocking_username FROM block)

      	      ORDER BY send_time DESC
      	      ) AS senders;

    END;

